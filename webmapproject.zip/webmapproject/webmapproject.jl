# WebMapProject
# Copyright (C) 2026 Katerina Kyriakou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or 
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.


using Genie
using Genie.Router
using Genie.Renderer.Html
using Genie.Requests
using DelimitedFiles
using Base64


const COAST_FILE_PATH = "coastline_points.txt"
const LOGO_FILE_PATH = "logo.png"
const R = 6371.0
const PHI0 = 45 * pi / 180
const LINEN = "rgb(250,240,230)"
const OCEAN = "rgb(209,225,242)"

if !isfile(COAST_FILE_PATH)
    error("Cannot find coastline_points.txt. Put this app in the same folder as coastline_points.txt and run it from that folder.")
end

if !isfile(LOGO_FILE_PATH)
    error("Cannot find logo.png. Put the logo PNG in the same folder as this app and run it from that folder.")
end

const LOGO_DATA_URI = "data:image/png;base64," * base64encode(read(LOGO_FILE_PATH))

coast_data = readdlm(COAST_FILE_PATH, ',', Float64)
const C_IDS = coast_data[:, 1]
const C_LONS = coast_data[:, 2]
const C_LATS = coast_data[:, 3]

const TITLES = Dict(
    1 => "Normal Equidistant Cylindrical",
    2 => "Normal Equivalent Cylindrical",
    3 => "Mercator",
    4 => "Normal Conic Equidistant",
    5 => "Normal Conformal Conic Projection (Lambert)",
    6 => "Normal Conic Equivalent (Albers)",
    7 => "Normal Azimuthal Equidistant (Postel)",
    8 => "Polar Stereographic",
    9 => "Polar Gnomonic",
    10 => "Polar Orthographic",
    11 => "Polar Equivalent (Lambert)",
    12 => "Transverse Cylindrical Equidistant (Cassini)",
    13 => "Transverse: Mercator"
)

jsnum(x; digits=6) = isfinite(Float64(x)) ?
string(round(Float64(x), digits=digits)) : "null"
jsarray(v) = "[" * join((x === nothing ? "null" : jsnum(x) for x in v), ",") * "]"
jsstr(s) = "\"" * replace(String(s), "\\"=>"\\\\", "\""=>"\\\"") * "\""

mod2pi(x) = mod(x + pi, 2pi) - pi

function project_point(lon_deg, lat_deg, choice, lon0_deg)
    lon = lon_deg * pi / 180
    lat = lat_deg * pi / 180
    lam0 = lon0_deg * pi / 180

    force_no_mod = choice >= 4 && choice <= 6
    adj = force_no_mod ?
(lon - lam0) : mod2pi(lon - lam0)

    if choice in (4, 5, 6) && lat <= -60 * pi / 180
        return nothing
    end

    if choice == 1
        return (R * adj, R * lat)
    elseif choice == 2
        return (R * adj, R * sin(lat))
    elseif choice == 3
        abs(lat) >= 85 * pi / 180 && return nothing
        return (R * adj, R * log(tan(pi / 4 + lat / 2)))
    elseif choice == 4
        r = R * (cot(PHI0) + PHI0 - lat)
        return (r * sin(adj * sin(PHI0)), r * cos(adj * sin(PHI0)))
    elseif choice == 5
        n = sin(PHI0)
        F = (cos(PHI0) * tan(pi / 4 + PHI0 / 2)^n) / n
        t = clamp(pi / 4 + lat / 2, 0.001, pi / 2 - 0.001)
        r = (R * F) / tan(t)^n
        return (r * sin(n * adj), r * cos(n * adj))
    elseif choice == 6
        n = sin(PHI0)
        C = cos(PHI0)^2 + 2 * n * sin(PHI0)
        r = (R / n) * sqrt(max(0.0, C - 2 * n * sin(lat)))
        return (r * sin(n * adj), r * cos(n * adj))
    elseif choice in (12, 13)
        B = cos(lat) * sin(adj)
        abs(B) >= 0.99 && return nothing
        u = atan(tan(lat), cos(adj))
        return choice == 12 ?
(R * asin(B), R * u) : (R * 0.5 * log((1 + B) / (1 - B)), R * u)
    elseif choice == 7
        rho = R * (pi / 2 - lat)
        return (rho * sin(adj), rho * cos(adj))
    elseif choice == 8
        lat <= -75 * pi / 180 && return nothing
        rho = 2 * R * tan(pi / 4 - lat / 2)
        return (rho * sin(adj), rho * cos(adj))
    elseif choice == 9
        lat <= 25 * pi / 180 && return nothing
        rr = R * tan(pi / 2 - lat)
        return (rr * sin(adj), rr * cos(adj))
    elseif choice == 10
        lat < 0 && return nothing
        rho = R * cos(lat)
        return (rho * sin(adj), rho * cos(adj))
    elseif choice == 11
        rho = 2 * R * sin((pi / 2 - lat) / 2)
        return (rho * sin(adj), rho * cos(adj))
    end

    return nothing
end

jump_limit(choice) = choice in (12, 13) ?
0.40 * pi * R : 0.70 * pi * R

function span_limit(choice)
    choice <= 3 && return 1.05 * 2 * pi * R
    choice in (7, 11) && return 1.80 * pi * R
    choice in (8, 9, 10) && return 2.20 * pi * R
    return 4.00 * pi * R
end

function valid_segment(x, y, choice)
    length(x) < 4 && return false
    spanx = maximum(x) - minimum(x)
    spany = maximum(y) - minimum(y)
    (spanx > span_limit(choice) || spany > span_limit(choice)) && return false

    if choice == 11
        for k in eachindex(x)
            sqrt(x[k]^2 + y[k]^2) > 2 * R * 0.995 && return false
        end
    end

    return true
end

function remove_from_coastline(lon, lat)
    return 46.0 <= lon <= 56.5 && 35.0 <= lat <= 48.5
end

function projected_segments(choice, lon0)
    segs = Vector{Tuple{Vector{Float64}, Vector{Float64}}}()
    sx = Float64[]
    sy = Float64[]
    prev = nothing
    lastid = C_IDS[1]
    jump = jump_limit(choice)

    function flush!()
        if valid_segment(sx, sy, choice)
            push!(segs, (copy(sx), copy(sy)))
        end
        empty!(sx)
        empty!(sy)
        return nothing
    end

    for i in eachindex(C_IDS)
        if C_IDS[i] != lastid
            flush!()
            prev = nothing
            lastid = C_IDS[i]
        end

        if remove_from_coastline(C_LONS[i], C_LATS[i])
             flush!()
            prev = nothing
            continue
        end

        p = project_point(C_LONS[i], C_LATS[i], choice, lon0)

        if p === nothing ||
!isfinite(p[1]) || !isfinite(p[2])
            flush!()
            prev = nothing
            continue
        end

        if prev !== nothing
            if abs(p[1] - prev[1]) > jump ||
abs(p[2] - prev[2]) > jump
                flush!()
                prev = nothing
            end
        end

        push!(sx, p[1])
        push!(sy, p[2])
        prev = p
    end

    flush!()
    return segs
end

function trace_json_2d(x, y, name; fill="", fillcolor="", linecolor="black", width=1.6)
    parts = String[
        "\"x\":" * jsarray(x),
        "\"y\":" * jsarray(y),
        "\"type\":\"scatter\"",
        "\"mode\":\"lines\"",
        "\"hoverinfo\":\"skip\"",
        "\"showlegend\":false",
        "\"name\":" * jsstr(name),
        "\"line\":{\"color\":" * jsstr(linecolor) * ",\"width\":$width}"
    ]

    if fill != ""
         push!(parts, "\"fill\":\"$fill\"")
        push!(parts, "\"fillcolor\":" * jsstr(fillcolor))
    end

    return "{" * join(parts, ",") * "}"
end

function append_orthographic_boundary_arc!(x, y)
    # Orthographic visible boundary is the circle with radius R.
    # When a land polygon is clipped by the horizon, the visible polygon must
    # close along this circular edge, not with a straight chord.
length(x) < 2 && return

    θ1 = atan(x[end], y[end])
    θ2 = atan(x[1], y[1])

    dθ = mod(θ2 - θ1 + pi, 2pi) - pi
    n = max(8, Int(ceil(abs(dθ) / (pi / 36))))

    for k in 1:n
        θ = θ1 + dθ * k / n
        push!(x, R * sin(θ))
        push!(y, R * cos(θ))
    end
end

function orthographic_fill_segments(lon0)
    segs = Vector{Tuple{Vector{Float64}, Vector{Float64}}}()

    sx = Float64[]
    sy = Float64[]
    prev = nothing
    lastid = C_IDS[1]
    segment_was_clipped = false
    jump = jump_limit(10)

    function flush!()
        if length(sx) > 3
            xfill = copy(sx)
            yfill = copy(sy)

            if segment_was_clipped
                append_orthographic_boundary_arc!(xfill, yfill)
            end

            if valid_segment(xfill, yfill, 10)
                push!(segs, (xfill, yfill))
            end
        end

        empty!(sx)
        empty!(sy)
        prev = nothing
        segment_was_clipped = false
        return nothing
    end

    for i in eachindex(C_IDS)
        if C_IDS[i] != lastid
            flush!()
            lastid = C_IDS[i]
        end

        if remove_from_coastline(C_LONS[i], C_LATS[i])
            flush!()
             prev = nothing
            continue
        end

        p = project_point(C_LONS[i], C_LATS[i], 10, lon0)

        if p === nothing ||
!isfinite(p[1]) || !isfinite(p[2])
            segment_was_clipped = true
            continue
        end

        if prev !== nothing
            if abs(p[1] - prev[1]) > jump ||
abs(p[2] - prev[2]) > jump
                flush!()
            end
        end

        push!(sx, p[1])
        push!(sy, p[2])
        prev = p
    end

    flush!()
    return segs
end

function append_gnomonic_boundary_arc!(x, y)
length(x) < 2 && return

    r_boundary = R * tan(pi / 2 - 25 * pi / 180)

    θ1 = atan(x[end], y[end])
    θ2 = atan(x[1], y[1])

    dθ = mod(θ2 - θ1 + pi, 2pi) - pi
    n = max(8, Int(ceil(abs(dθ) / (pi / 36))))

    for k in 1:n
        θ = θ1 + dθ * k / n
        push!(x, r_boundary * sin(θ))
        push!(y, r_boundary * cos(θ))
    end
end

function gnomonic_fill_segments(lon0)
segs = Vector{Tuple{Vector{Float64}, Vector{Float64}}}()

    sx = Float64[]
    sy = Float64[]
    prev = nothing
    lastid = C_IDS[1]
    segment_was_clipped = false
    jump = jump_limit(9)

    function flush!()
        if length(sx) > 3
            xfill = copy(sx)
            yfill = copy(sy)

            if segment_was_clipped
                append_gnomonic_boundary_arc!(xfill, yfill)
            end

            if valid_segment(xfill, yfill, 9)
                push!(segs, (xfill, yfill))
            end
        end

        empty!(sx)
        empty!(sy)
         prev = nothing
        segment_was_clipped = false
        return nothing
    end

    for i in eachindex(C_IDS)
        if C_IDS[i] != lastid
            flush!()
            lastid = C_IDS[i]
        end

        if remove_from_coastline(C_LONS[i], C_LATS[i])
             flush!()
            prev = nothing
            continue
        end

        p = project_point(C_LONS[i], C_LATS[i], 9, lon0)

        if p === nothing ||
!isfinite(p[1]) || !isfinite(p[2])
            segment_was_clipped = true
            continue
        end

        if prev !== nothing
            if abs(p[1] - prev[1]) > jump ||
abs(p[2] - prev[2]) > jump
                flush!()
            end
        end

        push!(sx, p[1])
        push!(sy, p[2])
        prev = p
    end

    flush!()
    return segs
end



function cylindrical_y_from_lat(choice, lat_deg)
    lat = lat_deg * pi / 180

    if choice == 1
        return R * lat
    elseif choice == 2
        return R * sin(lat)
    elseif choice == 3
        latc = clamp(lat, -85 * pi / 180, 85 * pi / 180)
        return R * log(tan(pi / 4 + latc / 2))
    end

    return R * lat
end

function cylindrical_y_bounds(choice)
    if choice == 1
        return (-pi / 2 * R, pi / 2 * R)
    elseif choice == 2
        return (-R, R)
    elseif choice == 3
        return (-20000.0, 20000.0)
    end

    return (-R, R)
end

function clip_poly_edge(poly, inside, intersect)
    isempty(poly) && return poly

    out = Vector{Tuple{Float64, Float64}}()
    s = poly[end]
    s_in = inside(s)

    for e in poly
        e_in = inside(e)

        if e_in
            if !s_in
                push!(out, intersect(s, e))
            end
            push!(out, e)
        elseif s_in
            push!(out, intersect(s, e))
        end

        s = e
        s_in = e_in
    end

    return out
end

function clip_polygon_rect(poly, xmin, xmax, ymin, ymax)
    p = clip_poly_edge(poly, q -> q[1] >= xmin, (a, b) -> begin
        t = (xmin - a[1]) / (b[1] - a[1] + eps())
        (xmin, a[2] + t * (b[2] - a[2]))
    end)
    p = clip_poly_edge(p, q -> q[1] <= xmax, (a, b) -> begin
        t = (xmax - a[1]) / (b[1] - a[1] + eps())
        (xmax, a[2] + t * (b[2] - a[2]))
    end)
    p = clip_poly_edge(p, q -> q[2] >= ymin, (a, b) -> begin
        t = (ymin - a[2]) / (b[2] - a[2] + eps())
        (a[1] + t * (b[1] - a[1]), ymin)
    end)
    p = clip_poly_edge(p, q -> q[2] <= ymax, (a, b) -> begin
        t = (ymax - a[2]) / (b[2] - a[2] + eps())
        (a[1] + t * (b[1] - a[1]), ymax)
    end)

    return p
end

function cylindrical_fill_segments(choice, lon0)
    segs = Vector{Tuple{Vector{Float64}, Vector{Float64}}}()
    xmin = -pi * R
    xmax = pi * R
    ymin, ymax = cylindrical_y_bounds(choice)
    lam0 = lon0 * pi / 180

    startidx = 1

    while startidx <= length(C_IDS)
        id = C_IDS[startidx]
        stopidx = startidx
        while stopidx <= length(C_IDS) && C_IDS[stopidx] == id
            stopidx += 1
        end
        idxs = startidx:(stopidx - 1)

        adj_unwrapped = Float64[]
        ys = Float64[]
        lats = Float64[]
        prev = nothing

        for i in idxs
            lon = C_LONS[i]
            lat = C_LATS[i]

            remove_from_coastline(lon, lat) && continue
            choice == 3 && abs(lat) >= 85 && continue

            raw = mod2pi(lon * pi / 180 - lam0)
            if prev === nothing
                adj = raw
            else
                adj = raw + 2pi * round((prev - raw) / (2pi))
            end

            push!(adj_unwrapped, adj)
            push!(ys, cylindrical_y_from_lat(choice, lat))
            push!(lats, lat)
            prev = adj
        end

        if length(adj_unwrapped) >= 3
            for shift in (-2pi, 0.0, 2pi)
                poly = Tuple{Float64, Float64}[]

                for k in eachindex(adj_unwrapped)
                    push!(poly, (R * (adj_unwrapped[k] + shift), ys[k]))
                end
                if !isempty(lats) && maximum(lats) < -55
                    push!(poly, (poly[end][1], ymin))
                    push!(poly, (poly[1][1], ymin))
                end

                clipped = clip_polygon_rect(poly, xmin, xmax, ymin, ymax)

                if length(clipped) >= 4
                    x = [q[1] for q in clipped]
                    y = [q[2] for q in clipped]

                    if valid_segment(x, y, choice)
                        push!(segs, (x, y))
                    end
                end
            end
        end

        startidx = stopidx
    end

    return segs
end

function fill_segments_for_choice(choice, lon0)
    choice in (1, 2, 3) && return cylindrical_fill_segments(choice, lon0)
    choice == 10 && return orthographic_fill_segments(lon0)
    choice == 9 && return gnomonic_fill_segments(lon0)
    return projected_segments(choice, lon0)
end

function landfill_json(choice, lon0)
    fill_segments = fill_segments_for_choice(choice, lon0)

    [trace_json_2d(x, y, "landfill"; fill="toself", fillcolor=LINEN, linecolor="rgba(0,0,0,0)", width=0)
     for (x, y) in fill_segments]
end

function coastline_json(choice, lon0)
    [trace_json_2d(x, y, "coastline"; linecolor="rgba(71,117,255,1.0)", width=0.8)
     for (x, y) in projected_segments(choice, lon0)]
end

function push_projected!(x, y, p, prev, jump)
    if p === nothing ||
!isfinite(p[1]) || !isfinite(p[2])
        push!(x, nothing)
        push!(y, nothing)
        return nothing
    end

    if prev !== nothing && (abs(p[1] - prev[1]) > jump || abs(p[2] - prev[2]) > jump)
        push!(x, nothing)
        push!(y, nothing)
    end

    push!(x, p[1])
    push!(y, p[2])
    return p
end

function graticule_arrays(choice, lon0, step)
    out = Vector{Tuple{Vector{Any}, Vector{Any}}}()
     lat_start = choice >= 4 && choice <= 6 ?
-60.0 : -75.0

    lat = lat_start
    while lat <= 75.0 + 1e-9
        x = Any[]
        y = Any[]
        prev = nothing

        for k in 0:239
            lon = -180 + 360 * k / 239
            prev = push_projected!(x, y, project_point(lon, lat, choice, lon0), prev, 0.5 * pi * R)
        end

        push!(out, (x, y))
        lat += step
    end

    lon = -180.0
    while lon <= 180.0 + 1e-9
        x = Any[]
        y = Any[]
        prev = nothing
        a = choice >= 4 && choice <= 6 ?
-60.0 : -85.0

        for k in 0:239
            lat2 = a + (85 - a) * k / 239
            prev = push_projected!(x, y, project_point(lon, lat2, choice, lon0), prev, 0.5 * pi * R)
        end

        push!(out, (x, y))
        lon += step
    end

    return out
end

function graticule_json(choice, lon0, step)
    [trace_json_2d(x, y, "graticule"; linecolor="rgba(40,40,40,.35)", width=0.6)
     for (x, y) in graticule_arrays(choice, lon0, step)]
end

function ellipse_arrays(choice, lon0, step)
    out = Vector{Tuple{Vector{Float64}, Vector{Float64}}}()
    lat_start = choice >= 4 && choice <= 6 ?
-60.0 : -75.0

    latd = lat_start
    while latd <= 75.0 + 1e-9
        if latd > -85 && latd < 85
            lond = -180.0

            while lond <= 180.0 + 1e-9
                eps = 1e-5
                base = project_point(lond, latd, choice, lon0)
                plon = project_point(lond + eps * 180 / pi, latd, choice, lon0)
                plat = project_point(lond, latd + eps * 180 / pi, choice, lon0)

                if base !== nothing && plon !== nothing && plat !== nothing
                     lat = latd * pi / 180
                    c = cos(lat)

                    if abs(c) >= 0.05
                        dxdl = (plon[1] - base[1]) / eps
                        dydl = (plon[2] - base[2]) / eps
                        dxdp = (plat[1] - base[1]) / eps
                        dydp = (plat[2] - base[2]) / eps

                        x = Float64[]
                        y = Float64[]

                        for k in 0:36
                            t = 2 * pi * k / 36
                             push!(x, base[1] + (cos(t) * dxdl / c + sin(t) * dxdp) * 0.05)
                            push!(y, base[2] + (cos(t) * dydl / c + sin(t) * dydp) * 0.05)
                        end

                         push!(out, (x, y))
                    end
                end

                lond += step
            end
        end

         latd += step
    end

    return out
end

function ellipses_json(choice, lon0, step)
    [trace_json_2d(x, y, "ellipses"; linecolor="rgba(220,30,30,.55)", width=1.5)
     for (x, y) in ellipse_arrays(choice, lon0, step)]
end

function fixed_ranges_json(choice)
    if choice == 1
        return "\"xrange\":" * jsarray([-pi * R, pi * R]) * ",\"yrange\":" * jsarray([-pi / 2 * R, pi / 2 * R])
    elseif choice == 2
        return "\"xrange\":" * jsarray([-pi * R, pi * R]) * ",\"yrange\":" * jsarray([-R, R])
    elseif choice == 3
        return "\"xrange\":" * jsarray([-pi * R, pi * R]) * ",\"yrange\":" * jsarray([-20000.0, 20000.0])
    else
        return "\"xrange\":null,\"yrange\":null"
    end
end

function map_point_to_3d(x, y, choice)
    if x === nothing ||
y === nothing
        return (nothing, nothing, nothing)
    end

    xf = Float64(x)
    yf = Float64(y)

    if !isfinite(xf) ||
!isfinite(yf)
        return (nothing, nothing, nothing)
    end

    if choice in (1, 2, 3)
        theta = xf / R
        radius = R
        return (-radius * sin(theta), radius * cos(theta), yf)
    elseif choice in (4, 5, 6)
        rho = sqrt(xf^2 + yf^2)
        theta = atan(xf, yf)
         cone_angle = pi / 5
        rr = rho * sin(cone_angle)
        h = -rho * cos(cone_angle)
        return (-rr * sin(theta), rr * cos(theta), h)
    elseif choice in (12, 13)
        theta = xf / R
        radius = R
        return (yf, -radius * sin(theta), radius * cos(theta))
    else
         return (xf, yf, 0.0)
    end
end


function surfacecolor_matrix_json(zrows)
    rows = String[]
    for row in zrows
        push!(rows, jsarray(row))
    end
    return "[" * join(rows, ",") * "]"
end

function trace_json_surface3d_wrapped(xrows, yrows, zrows, colorrows)
return "{" *
        "\"x\":[" * join([jsarray(row) for row in xrows], ",") * "]," *
        "\"y\":[" * join([jsarray(row) for row in yrows], ",") * "]," *
        "\"z\":[" * join([jsarray(row) for row in zrows], ",") * "]," *
        "\"surfacecolor\":" * surfacecolor_matrix_json(colorrows) * "," *
        "\"type\":\"surface\"," *
        "\"colorscale\":[[0," * jsstr(OCEAN) * "],[0.499," * jsstr(OCEAN) * "],[0.5," * jsstr(LINEN) * "],[1," * jsstr(LINEN) * "]]," *
        "\"cmin\":0,\"cmax\":1," *
        "\"showscale\":false," *
        "\"opacity\":1.0," *
        "\"lighting\":{\"ambient\":1,\"diffuse\":0,\"specular\":0,\"roughness\":1,\"fresnel\":0}," *
        "\"lightposition\":{\"x\":0,\"y\":0,\"z\":100000}," *
        "\"hoverinfo\":\"skip\"," *
        "\"showlegend\":false," *
        "\"name\":\"wrapped_2d_colours\"" *
    "}"
end

function point_in_poly(px, py, x, y)
    inside = false
    n = length(x)
    n < 3 && return false

    j = n
    for i in 1:n
        yi = y[i]
        yj = y[j]
        xi = x[i]
        xj = x[j]

        if ((yi > py) != (yj > py))
            xcross = (xj - xi) * (py - yi) / (yj - yi + eps()) + xi
            if px < xcross
                inside = !inside
            end
        end

        j = i
    end

    return inside
end

function point_is_land(px, py, fill_segments)
    for (x, y) in fill_segments
        if point_in_poly(px, py, x, y)
             return true
        end
    end

    return false
end

function finite_minmax_from_segments(segs)
    xs = Float64[]
    ys = Float64[]

    for (x, y) in segs
        append!(xs, x)
        append!(ys, y)
    end

    if isempty(xs) ||
isempty(ys)
        return (-R, R, -R, R)
    end

    return (minimum(xs), maximum(xs), minimum(ys), maximum(ys))
end

function surface_ranges_for_wrapped_2d(choice, lon0, fill_segments)
    if choice == 1
        return (-pi * R, pi * R, -pi / 2 * R, pi / 2 * R)
    elseif choice == 2
        return (-pi * R, pi * R, -R, R)
    elseif choice == 3
        return (-pi * R, pi * R, -20000.0, 20000.0)
    else
        coast = projected_segments(choice, lon0)
        xmin, xmax, ymin, ymax = finite_minmax_from_segments(vcat(coast, fill_segments))

        dx = xmax - xmin
        dy = ymax - ymin

        if dx <= 0 ||
dy <= 0
            return (-R, R, -R, R)
        end

        pad = 0.04 * max(dx, dy)

        if choice in (12, 13)
            return (-pi * R, pi * R, ymin - pad, ymax + pad)
        end

        return (xmin - pad, xmax + pad, ymin - pad, ymax + pad)
    end
end

function wrapped_2d_colour_surface_json(choice, lon0)
    fill_segments = fill_segments_for_choice(choice, lon0)

    xmin, xmax, ymin, ymax = surface_ranges_for_wrapped_2d(choice, lon0, fill_segments)

    nx = choice in (1, 2, 3, 12, 13) ?
96 : 80
    ny = 60

    xrows = Vector{Vector{Any}}()
    yrows = Vector{Vector{Any}}()
    zrows = Vector{Vector{Any}}()
    crows = Vector{Vector{Float64}}()

    for j in 0:ny
        yy = ymin + (ymax - ymin) * j / ny

        xr = Any[]
        yr = Any[]
        zr = Any[]
        cr = Float64[]

         for i in 0:nx
            xx = xmin + (xmax - xmin) * i / nx

            p = map_point_to_3d(xx, yy, choice)

            push!(xr, p[1])
            push!(yr, p[2])
            push!(zr, p[3])
            push!(cr, point_is_land(xx, yy, fill_segments) ? 1.0 : 0.0)
        end

        push!(xrows, xr)
        push!(yrows, yr)
        push!(zrows, zr)
        push!(crows, cr)
    end

    return trace_json_surface3d_wrapped(xrows, yrows, zrows, crows)
end

function lift_3d_point(p, choice, factor)
    x, y, z = p

    if x === nothing ||
y === nothing || z === nothing
        return (nothing, nothing, nothing)
    end

if choice in (1, 2, 3)
        return (x * factor, y * factor, z)
    elseif choice in (4, 5, 6)
        cone_angle = pi / 5
        rr = sqrt(x^2 + y^2)

        if rr < 1e-9
            return (x, y, z + (factor - 1.0) * R)
        end

        ux = x / rr
        uy = y / rr

        d = max((factor - 1.0) * R, 120.0)

        return (
            x + d * cos(cone_angle) * ux,
            y + d * cos(cone_angle) * uy,
            z + d * sin(cone_angle)
        )
    elseif choice in (12, 13)
        return (x, y * factor, z * factor)
     else
        return (x, y, z + (factor - 1.0) * R)
    end
end



function polygon_scan_intervals(x, y, yy)
    xs = Float64[]
    n = length(x)
    n < 3 && return Tuple{Float64, Float64}[]

    for i in 1:n
        j = i == n ?
1 : i + 1
        x1 = x[i]
        y1 = y[i]
        x2 = x[j]
        y2 = y[j]

if (y1 <= yy < y2) || (y2 <= yy < y1)
            t = (yy - y1) / (y2 - y1)
            push!(xs, x1 + t * (x2 - x1))
        end
    end

    sort!(xs)

    out = Tuple{Float64, Float64}[]
    k = 1
    while k + 1 <= length(xs)
        a = xs[k]
         b = xs[k + 1]
        b > a && push!(out, (a, b))
        k += 2
    end

    return out
end

function trace_json_3d_landfill_ribbons(x, y, choice)
length(x) < 4 && return nothing

    ymin = minimum(y)
    ymax = maximum(y)
    dy = ymax - ymin
    dy <= 0 && return nothing

    bands = clamp(Int(ceil(dy / (R * 0.004))), 120, 900)

    X = Any[]
    Y = Any[]
    Z = Any[]

    for b in 0:bands
        yy = ymin + dy * b / bands
        intervals = polygon_scan_intervals(x, y, yy)

        for (a, bb) in intervals
            samples = clamp(Int(ceil(abs(bb - a) / (R * 0.004))), 12, 520)

            for s in 0:samples
                xx = a + (bb - a) * s / samples
                p = map_point_to_3d(xx, yy, choice)
                 push!(X, p[1])
                push!(Y, p[2])
                push!(Z, p[3])
            end

            push!(X, nothing)
            push!(Y, nothing)
            push!(Z, nothing)
         end
    end

    length(X) < 4 && return nothing

    return "{" *
        "\"x\":" * jsarray(X) * "," *
        "\"y\":" * jsarray(Y) * "," *
        "\"z\":" * jsarray(Z) * "," *
        "\"type\":\"scatter3d\",\"mode\":\"lines\"," *
        "\"line\":{\"color\":" * jsstr(LINEN) * ",\"width\":7}," *
        "\"hoverinfo\":\"skip\",\"showlegend\":false,\"name\":\"landfill3d\"" *
    "}"
end

function landfill3d_json(choice, lon0)
     fill_segments = fill_segments_for_choice(choice, lon0)

    traces = String[]

    for (x, y) in fill_segments
        tr = trace_json_3d_landfill_ribbons(x, y, choice)
        tr !== nothing && push!(traces, tr)
    end

    return traces
end



function ocean_surface3d_json(choice, lon0)
    fill_segments = fill_segments_for_choice(choice, lon0)

    xs = Float64[]
    ys = Float64[]

    for (x, y) in fill_segments
        append!(xs, x)
        append!(ys, y)
    end

    xmin = minimum(xs)
    xmax = maximum(xs)
    ymin = minimum(ys)
    ymax = maximum(ys)

    dx = xmax - xmin
    dy = ymax - ymin
    pad = 0.04 * max(dx, dy)

    if choice in (12, 13)
        xmin = -pi * R
        xmax = pi * R
        ymin -= pad
        ymax += pad
    else
        xmin -= pad
        xmax += pad
        ymin -= pad
        ymax += pad
    end

    nx = choice in (1,2,3,12,13) ?
120 : 80
    ny = choice in (1,2,3,12,13) ?
80 : 60

    X = Vector{Vector{Any}}()
    Y = Vector{Vector{Any}}()
    Z = Vector{Vector{Any}}()

    for j in 0:ny
        yy = ymin + (ymax - ymin) * j / ny

        xr = Any[]
        yr = Any[]
        zr = Any[]

        for i in 0:nx
            xx = xmin + (xmax - xmin) * i / nx
            p = map_point_to_3d(xx, yy, choice)

            push!(xr, p[1])
            push!(yr, p[2])
            push!(zr, p[3])
        end

        push!(X, xr)
        push!(Y, yr)
        push!(Z, zr)
     end

    ocean_rows = ["[" * join(fill(0, nx + 1), ",") * "]" for _ in 0:ny]

    return "{" *
        "\"x\":[" * join([jsarray(r) for r in X], ",") * "]," *
        "\"y\":[" * join([jsarray(r) for r in Y], ",") * "]," *
        "\"z\":[" * join([jsarray(r) for r in Z], ",") * "]," *
        "\"type\":\"surface\"," *
        "\"showscale\":false," *
         "\"opacity\":1.0," *
        "\"colorscale\":[[0," * jsstr(OCEAN) * "],[1," * jsstr(OCEAN) * "]]," *
        "\"surfacecolor\":[" * join(ocean_rows, ",") * "]," *
        "\"cmin\":0,\"cmax\":1," *
        "\"lighting\":{\"ambient\":1,\"diffuse\":0,\"specular\":0,\"roughness\":1,\"fresnel\":0}," *
        "\"hoverinfo\":\"skip\",\"showlegend\":false,\"name\":\"ocean3d\"" *
    "}"
end


function trace_json_3d_from_2d(x, y, name, choice;
color="black", width=1.6, lift=1.03)
    X = Any[]
    Y = Any[]
    Z = Any[]

    lift_this_layer = name == "graticule" || name == "ellipses"

    effective_lift = choice in (4, 5, 6) ?
max(lift, 1.02) : lift

    for i in eachindex(x)
        p = lift_this_layer ?
            lift_3d_point(map_point_to_3d(x[i], y[i], choice), choice, effective_lift) :
            map_point_to_3d(x[i], y[i], choice)

        push!(X, p[1])
        push!(Y, p[2])
        push!(Z, p[3])
    end

    return "{" *
        "\"x\":" * jsarray(X) * "," *
        "\"y\":" * jsarray(Y) * "," *
        "\"z\":" * jsarray(Z) * "," *
        "\"type\":\"scatter3d\",\"mode\":\"lines\"," *
        "\"line\":{\"color\":" * jsstr(color) * ",\"width\":$width}," *
        "\"hoverinfo\":\"skip\",\"showlegend\":false,\"name\":" * jsstr(name) *
    "}"
end

function traces3d_json(choice, lon0, step, show_ellipses, show_graticule)
    traces = String[]

    push!(traces, ocean_surface3d_json(choice, lon0))

    append!(traces, landfill3d_json(choice, lon0))

    for (x, y) in projected_segments(choice, lon0)
        push!(traces, trace_json_3d_from_2d(x, y, "coastline", choice; color="rgba(62,154,252,1.0)", width=1.5))
    end

    if show_graticule
        for (x, y) in graticule_arrays(choice, lon0, step)
            local_lift = choice in (7, 8, 9, 10, 11) ? 1.002 : 1.01
            push!(traces, trace_json_3d_from_2d(x, y, "graticule", choice; color="rgba(40,40,40,.35)", width=2, lift=local_lift))
        end
    end

    if show_ellipses
        for (x, y) in ellipse_arrays(choice, lon0, step)
            local_lift = choice in (7, 8, 9, 10, 11) ? 1.002 : 1.01
            push!(traces, trace_json_3d_from_2d(x, y, "ellipses", choice; color="rgba(220,30,30,.55)", width=4, lift=local_lift))
        end
     end

    return traces
end

route("/plotdata") do
    choice = parse(Int, getpayload(:choice, "1"))
    lon0 = parse(Float64, getpayload(:lon0, "0"))
    step = parse(Int, getpayload(:step, "30"))
    show_ellipses = getpayload(:ellipses, "true") == "true"
    show_graticule = getpayload(:graticule, "true") == "true"

    traces2d = String[]
    append!(traces2d, landfill_json(choice, lon0))
    append!(traces2d, coastline_json(choice, lon0))
    show_graticule && append!(traces2d, graticule_json(choice, lon0, step))
     show_ellipses && append!(traces2d, ellipses_json(choice, lon0, step))

    traces3d = traces3d_json(choice, lon0, step, show_ellipses, show_graticule)

    return raw"""{"title":""" * jsstr(TITLES[choice]) * "," *
           fixed_ranges_json(choice) * "," *
           "\"traces2d\":[" * join(traces2d, ",") * "]," *
           "\"traces3d\":[" * join(traces3d, ",") * "]" *
           "}"
end

const PAGE = replace(raw"""
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title> WebMapProject </title>
  <script src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>
  <style>
   body{
    margin:0;
    background:#eef1f5;
    font-family:Arial, Helvetica, sans-serif;
    color:#17233c;
}

.app-header{
    position:relative;
    display:flex;
    align-items:center;
    height:90px;
    padding:0 30px;
    background:rgb(18,60,100);
    box-shadow:0 2px 8px rgba(0,0,0,.25);
}

.app-header img{
    height:70px;
    width:auto;
}

.app-title{
    position:absolute;
    left:50%;
    top:50%;
    transform:translate(-50%,-50%);
    color:#fff;
    font-size:36px;
    font-weight:bold;
    letter-spacing:1px;
    text-shadow:0 1px 3px rgba(0,0,0,.35);
}

.page{
    padding:18px 20px 0 20px;
}
    
    .row { display:flex; gap:14px; width:100%; box-sizing:border-box; }
    .card { background:white; border-radius:6px;
 box-shadow:0 1px 4px rgba(0,0,0,.25); overflow:hidden; }
    .map-card { height:65vh; flex:1; }
    .plot { width:100%;
 height:100%; }
    .controls { margin-top:20px; padding:16px 12px; align-items:center; }
    .col-5 { flex:5; padding:0 4px;
 }
    .col-4 { flex:4; padding:0 12px; }
    .col-3 { flex:3; padding:0 28px;
 }
    label, .caption { display:block; font-size:12px; font-weight:700; margin-bottom:6px; color:#26324d; }
    .caption.upper { font-size:11px; color:#999;
 text-transform:uppercase; letter-spacing:.04em; }
    select { width:100%; border:0; background:#eee; padding:10px; height:36px; color:#5a5a5a; border-radius:2px;
 }
    input[type=range] { width:100%; accent-color:#16a7df; }
    .checkrow { font-size:13px; margin:7px 0; color:#222; display:flex; align-items:center;
 gap:8px; }
    #status { margin:10px 0 0 0; color:#b00020; font-size:13px; min-height:18px;
 }
    .genie { text-align:center; color:#8c9bb2; margin-top:10px; font-size:12px;
 }
  </style>
</head>
<body>
<div class="app-header">
    <img src="__LOGO_DATA_URI__" alt="University of West Attica Logo">
    <div class="app-title">WebMapProject</div>
</div>
<div class="page">
  <div class="row">
    <div class="card map-card"><div id="plot2d" class="plot"></div></div>
    <div class="card map-card"><div id="plot3d" class="plot"></div></div>
  </div>
  <div id="status"></div>
  <div class="card row controls">
    <div class="col-5">
      <label>Select Map Projection</label>
      <select id="projection">
        <option value="1">Normal Equidistant Cylindrical</option>
        <option value="2">Normal Equivalent Cylindrical</option>
        <option value="3">Mercator</option>
        <option value="4">Normal Conic Equidistant</option>
        <option  value="5">Normal Conformal Conic Projection (Lambert)</option>
        <option value="6">Normal Conic Equivalent (Albers)</option>
        <option value="7">Normal Azimuthal Equidistant (Postel)</option>
        <option value="8">Polar Stereographic</option>
        <option value="9">Polar Gnomonic</option>
        <option value="10">Polar Orthographic</option>
        <option value="11">Polar Equivalent (Lambert)</option>
        <option value="12">Transverse Cylindrical Equidistant (Cassini)</option>
        <option value="13">Transverse: Mercator</option>
      </select>
    </div>
    <div class="col-4">
       <div class="caption">Central Meridian: <span id="lon0label">0</span>°</div>
      <input id="lon0" type="range" min="-180" max="180" step="1" value="0" />
      <label>Grid Interval</label>
      <select id="gridstep">
        <option value="5">5°</option><option value="10">10°</option><option value="15">15°</option>
        <option value="20">20°</option><option value="25">25°</option><option selected value="30">30°</option>
      </select>
    </div>
    <div class="col-3">
      <div class="caption upper">Map Layers</div>
      <label class="checkrow"><input id="ellipses" type="checkbox" checked /> Show Tissot's Indicatrices</label>
      <label class="checkrow"><input  id="graticule" type="checkbox" checked /> Show Graticule</label>
    </div>
  </div>
  <div class="genie">Built with Genie</div>
</div>
<script>
const OCEAN = "rgb(209,225,242)";
 function status(msg){ document.getElementById('status').textContent = msg || ''; }

let timer = null;
function scheduleRender(){
  clearTimeout(timer);
  timer = setTimeout(render, 80);
 }

async function render(){
  try{
    if(typeof Plotly === 'undefined'){
      status('Plotly did not load. Check internet access.');
 return;
    }

    const choice = document.getElementById('projection').value;
    const lon0 = document.getElementById('lon0').value;
    const step = document.getElementById('gridstep').value;
 const ellipses = document.getElementById('ellipses').checked;
    const graticule = document.getElementById('graticule').checked;

    document.getElementById('lon0label').textContent = lon0;
    status('Rendering in Julia...');
 const url =
      "/plotdata?choice=" + choice +
      "&lon0=" + lon0 +
      "&step=" + step +
      "&ellipses=" + ellipses +
      "&graticule=" + graticule;
 const response = await fetch(url);
    const data = await response.json();

    status('');
 Plotly.react(
      'plot2d',
      data.traces2d,
      {
        title:{text:data.title, font:{size:18}},
        margin:{l:10,r:10,t:55,b:10},
        xaxis:{visible:false, scaleanchor:'y', autorange:true},
        yaxis:{visible:false, autorange:true},
        paper_bgcolor:'white',
        plot_bgcolor:OCEAN,
        showlegend:false
      },
      {displayModeBar:true, responsive:true}
    );
 const c = parseInt(choice);

    Plotly.react(
      'plot3d',
      data.traces3d,
      {
        title:{text:data.title, font:{size:18}},
        margin:{l:0,r:0,t:55,b:0},
        scene:{
          xaxis:{visible:false},
          yaxis:{visible:false},
          zaxis:{visible:false, range:([7,8,9,10,11].includes(c) ? [-7000,7000] : undefined)},
          aspectmode:'manual',
          aspectratio:([1,2,3].includes(c) ? {x:1,y:1,z:1.6}  : ([4,5,6].includes(c) ? {x:1.2,y:1.2,z:1.4} : {x:1,y:1,z:1}))
        },
        paper_bgcolor:'white',
        showlegend:false
      },
      {displayModeBar:true, responsive:true}
    );
 } catch(e) {
    status('Error: ' + e.message);
    console.error(e);
  }
}

['projection','gridstep','ellipses','graticule'].forEach(id => document.getElementById(id).addEventListener('change', scheduleRender));
document.getElementById('lon0').addEventListener('input', scheduleRender);
 window.addEventListener('resize', () => { if(typeof Plotly !== 'undefined'){ Plotly.Plots.resize('plot2d'); Plotly.Plots.resize('plot3d'); }});
window.addEventListener('load', render);
 </script>
</body>
</html>
""", "__LOGO_DATA_URI__" => LOGO_DATA_URI)

route("/") do
    html(PAGE; noparse=true)
end

up(8000; async=false)


